TITLE: 
Craftsmens studios website

AUTHOR:
DESIGNED & DEVELOPED by DHINESHKUMAR R

CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Stellar Parallax
http://markdalgleish.com/projects/stellar.js/

FlexSlider
https://www.woothemes.com/flexslider/